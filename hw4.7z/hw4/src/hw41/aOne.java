package hw41;

public class aOne {
    public static void main(String[] args) {
        short myNum = -250;
        short myNum1 = 250;
        int myNum2 = 4_589_498;
        double myNum3 = 10_000_000_000_000_000_000d;
        long myNum4 = -9_000_000_000_000_000_000L;
        System.out.println(myNum);
        System.out.println(myNum1);
        System.out.println(myNum2);
        System.out.println(myNum3);
        System.out.println(myNum4);
    }
}
