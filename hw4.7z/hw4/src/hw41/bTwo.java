package hw41;

public class bTwo {
    public static void main(String[] args) {
        int myNum = 43112;
        int myNum1 = -1_357_674;
        int myNum2 = 1_357_674;
        int myNum3 = -1_357_674_000;
        long myNum4 = 3_657_895_000L;
        System.out.println(myNum);
        System.out.println(myNum1);
        System.out.println(myNum2);
        System.out.println(myNum3);
        System.out.println(myNum4);
    }
}
