package hw41;

public class cThree {
    public static void main(String[] args) {
        float myNum = 4.987_654_3f;
        double myNum1 = 7.123_456_789_012_345_678_890d;
        float myNum2 = 18_398_458_438_583_853.28f;
        double myNum3 = 18_398_458_438_583_853.398_759_372_849_284_22d;
        System.out.println(myNum);
        System.out.println(myNum1);
        System.out.println(myNum2);
        System.out.println(myNum3);
       }
}
