package hw42;

public class fSix {
    public static void main(String[] args) {
        String firstName = "Dimka";
        String familyName = "Sarieva";
        byte age;
        age = 37;
        System.out.println(firstName + " " + familyName + " " + age);
        System.out.println(firstName + "\n" + familyName + "\n" + age);
        }
}
