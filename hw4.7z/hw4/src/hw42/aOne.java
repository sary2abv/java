package hw42;

public class aOne {
    public static void main(String[] args) {
        String firstName = "Miroslav";
        String familyName = "Sariev";

        System.out.println(firstName);
        System.out.println(familyName);

        System.out.println(firstName + "\n" + familyName);
        }
}
