package hw42;

public class cThree {
    public static void main(String[] args) {
        String firstName = "Miroslav";
        String familyName = "Sariev";
        System.out.println(firstName);
        System.out.println(firstName + familyName);
        }
}
