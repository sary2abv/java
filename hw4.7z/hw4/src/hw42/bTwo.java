package hw42;

public class bTwo {
    public static void main(String[] args) {
        String myName = "Miroslav";
        String myFriendName = "Petko";
        System.out.println(myName.equals(myFriendName));
        System.out.println(myName.equalsIgnoreCase(myFriendName));
        System.out.println(myName.compareTo(myFriendName));
        }
}
