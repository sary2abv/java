package hw42;

public class dFour {
    public static void main(String[] args) {
        String point4 = "Извежда вана нов ред";
        // не разбрах какво да направя
        System.out.println(point4);
        }
}
