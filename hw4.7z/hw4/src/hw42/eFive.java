package hw42;

public class eFive {
    public static void main(String[] args) {
        String firstName = "Miroslav";
        String familyName = "Sariev";
        byte age;
        age = 41;
        System.out.println(firstName +" "+ familyName +" "+ age);
        }
}
