package mypac;

public class main {
}
