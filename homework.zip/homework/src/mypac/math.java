package mypac;

public class math {
}
