package homework;

public class cThree {
    public static void main(String[] args) {
        System.out.print(Math.abs(-147));
        System.out.print(Math.abs(15));
        System.out.print(Math.abs(0));
        System.out.print(Math.abs(18));
        }
        }