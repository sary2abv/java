package homework;

public class bTwo {
    public static void main(String[] args) {
        // the answer is 3333
        System.out.println(1112 + 2221);
    }
}
