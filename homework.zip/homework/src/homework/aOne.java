package homework;

public class aOne {
    public static void main(String[] args) {
        System.out.println(Math.abs(-147));
       }
}