package homework;

public class dFour {
    public static void main(String[] args) {
        System.out.print(Math.sqrt(8));
        System.out.print(Math.sqrt(353));
        System.out.print(Math.sqrt(78));
        System.out.print(Math.sqrt(3));
        System.out.print(Math.sqrt(-67));
        System.out.print(Math.sqrt(723));
        System.out.print(Math.sqrt(2000));
        System.out.print(Math.sqrt(-100));
    }
}
