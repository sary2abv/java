package homework;

public class eFive {
    public static void main(String[] args) {
        System.out.print(Math.pow(-20, 2));
        System.out.print(Math.pow(92, 2));
        System.out.print(Math.pow(638, 2));
        System.out.print(Math.pow(73, 2));
        System.out.print(Math.pow(200, 2));
        System.out.print(Math.pow(-22, 2));
    }
}
